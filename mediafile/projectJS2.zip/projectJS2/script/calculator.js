const display = document.getElementById("display");
function operator(op) {
    if (display.value.charAt(display.value.length - 1) == '+' || display.value.charAt(display.value.length - 1) == '-' || display.value.charAt(display.value.length - 1) == '*' || display.value.charAt(display.value.length - 1) == '/') {
        display.value = display.value.substring(0, display.value.length - 1);
    }
    display.value += op;

}
function number(num) {
    display.value += num;
}
function calculate() {
    try {
        display.value = eval(display.value);
    }
    catch (err) {
        display.value = "Error";
    }

}
function clearr() {
    display.value = ' ';
}